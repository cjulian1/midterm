
import { useNavigate } from 'react-router-dom';
const WelcomePage = () => {

  const navigate = useNavigate();

  const sendEmail = () => {
    window.open('mailto:jowen22@murraystate.edu?subject=subject&body=body');
  };
 
    return (
      <div>
        <h1>Welcome to HackerCon</h1>
        <p>Welcome SuperHacker You Are Inz</p>

        <input placeholder="Username" type="text" id="username"></input>
        <input placeholder="Email" type="text" id="email"></input>
        <input placeholder="First Name" type="text" id="firstname"></input>
        <input placeholder="Last Name" type="text" id="lastname"></input>


        <button onClick={sendEmail}>Submit</button>
      </div>
    );
  };
  
  export default WelcomePage;
  
  