
import { useNavigate } from 'react-router-dom';
const QuizPage = () => {

  const navigate = useNavigate();

  let questionNum = 0;

  const goToWelcomePage = () => {
    navigate('/welcome'); // Navigate to the Welcome page
  };

  const nextQuestion = () => {
    if (questionNum == 0){
      if(document.getElementById("answer").value.toLowerCase() === 'document object model'){
        questionNum = 1;
        document.getElementById("question").innerHTML = "What does HTML stand for?";
        document.getElementById("answer").value = "";
      }
    } else {
      if (questionNum == 1){
        if(document.getElementById("answer").value.toLowerCase() === 'hypertext markup language' || document.getElementById("answer").value.toLowerCase() === 'hyper text markup language'){
          questionNum = 2;
          document.getElementById("question").innerHTML = "Which character indicates an end tag?";
          document.getElementById("answer").value = "";
        }
      } else {
        if(document.getElementById("answer").value.toLowerCase() === '/'){
          navigate('/welcome');
        }
      }
    }
  }
 
    return (
      <div>
        <h1>Take Quiz to Qualify</h1>
        <p id="welcomeTo">Welcome to the qualifier quiz</p>
        
        <p id="question">What does DOM stand for?</p>
        <input type="text" id="answer"></input>

        <button onClick={nextQuestion}>Submit</button>
      </div>
    );
  };
  
  export default QuizPage;
  
  