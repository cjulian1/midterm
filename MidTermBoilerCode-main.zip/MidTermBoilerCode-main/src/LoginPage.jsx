
import { useNavigate } from 'react-router-dom';
const LoginPage = () => {

  const navigate = useNavigate();

  const login = () => {
    if(document.getElementById("usernameBox").value === 'username'){
      if(document.getElementById("passwordBox").value === 'password'){
        navigate('/landing');
      }
    }
  }

    return (
      <div>
        <h1>Login Here</h1>
        <p>This is the Login Page.</p>
        <input placeholder="Username" type="text" id="usernameBox"></input>
        <input placeholder="Password" type="password" id="passwordBox"></input>
        <button onClick={login}>Login</button>
      </div>
    );
  };
  
  export default LoginPage;
  